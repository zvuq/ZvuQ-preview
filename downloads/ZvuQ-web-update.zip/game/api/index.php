<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function reply(int $status, array $body): void { http_response_code($status); echo json_encode($body, JSON_UNESCAPED_UNICODE); exit; }
if (!in_array($_SERVER['REQUEST_METHOD'], ['GET','POST'], true)) reply(405,['error'=>'Nepodporovaná metoda.']);
try {
 $path=__DIR__.'/private/config.php';
 if (!is_file($path)) reply(503,['error'=>'Žebříček zatím není nastavený.']);
 $c=require $path;
 if (strpos($c['secret'], 'DOPLN')!==false || strlen($c['secret'])<32) reply(503,['error'=>'Žebříček zatím není nastavený.']);
 $db=new PDO('mysql:host='.$c['host'].';dbname='.$c['database'].';charset=utf8mb4',$c['user'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false]);
 if ($_SERVER['REQUEST_METHOD']==='GET') {
  $rows=$db->query('SELECT nickname, score, round_no AS round, created_at, avatar_json AS avatar FROM phase_scores ORDER BY score DESC, round_no DESC, created_at ASC, id ASC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);
  foreach ($rows as &$row) { $row['avatar']=$row['avatar']===null?null:json_decode($row['avatar'],true); }
  unset($row);
  reply(200,['scores'=>$rows]);
 }
 if (($_SERVER['HTTP_SEC_FETCH_SITE']??'')==='cross-site') reply(403,['error'=>'Neplatný původ požadavku.']);
 if (stripos($_SERVER['CONTENT_TYPE']??'', 'application/json')!==0) reply(415,['error'=>'Očekáván JSON.']);
 $raw=file_get_contents('php://input',false,null,0,4097);
 if (strlen($raw)>4096) reply(413,['error'=>'Příliš velký požadavek.']);
 $in=json_decode($raw,true);
 if (!is_array($in)) reply(400,['error'=>'Neplatná data.']);
 session_name('phase_rider');
 session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Strict','cookie_secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','use_strict_mode'=>true]);
 $action=$in['action']??'';
 if (!in_array($action,['start','submit'],true)) reply(400,['error'=>'Neplatná akce.']);
 // Persistent per-IP limits; use only REMOTE_ADDR, never client supplied forwarding headers.
 $ip=hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',$c['secret']);
 $bucket=(int)floor(time()/600);
 $q=$db->prepare('INSERT INTO phase_limits (ip_hash,bucket,action,hits) VALUES (?,?,?,1) ON DUPLICATE KEY UPDATE hits=hits+1'); $q->execute([$ip,$bucket,$action]);
 $q=$db->prepare('SELECT hits FROM phase_limits WHERE ip_hash=? AND bucket=? AND action=?'); $q->execute([$ip,$bucket,$action]);
 if ((int)$q->fetchColumn()>($action==='start'?80:30)) reply(429,['error'=>'Příliš mnoho pokusů. Počkej několik minut.']);
 if (random_int(1,50)===1) $db->exec('DELETE FROM phase_limits WHERE bucket < '.($bucket-144));
 if ($action==='start') {
  $appearance=$in['avatar']??null;
  if ($appearance!==null) {
   if (!is_array($appearance) || !in_array($appearance['character']??null,['dj','djane'],true)) reply(422,['error'=>'Neplatná postava.']);
   $limits=['head'=>4,'skin'=>4,'hair'=>8,'hairColor'=>4,'top'=>4,'color'=>4,'pants'=>4,'shoes'=>4,'accessory'=>6,'ride'=>3,'earrings'=>2];
   $clean=['character'=>$appearance['character']];
   foreach ($limits as $key=>$count) {
    $value=$appearance[$key]??null;
    if(!array_key_exists($key,$appearance)){
      if($key==='ride')$value=1;
      if($key==='earrings')$value=$appearance['character']==='djane'?1:0;
    }
    if (!is_int($value)||$value<0||$value>=$count) reply(422,['error'=>'Neplatný vzhled postavy.']);
    $clean[$key]=$value;
   }
   $appearance=$clean;
  }
  $token=bin2hex(random_bytes(32));
  $_SESSION['runs']=array_filter($_SESSION['runs']??[],static function($r){return $r['started']>microtime(true)-7200;});
  while (count($_SESSION['runs'])>=8) array_shift($_SESSION['runs']);
  $_SESSION['runs'][$token]=['started'=>microtime(true),'avatar'=>$appearance];
  reply(200,['token'=>$token]);
 }
 $token=$in['token']??'';
 if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D',$token) || !isset($_SESSION['runs'][$token])) reply(403,['error'=>'Chybí platná herní relace. Zahraj novou hru.']);
 $name=trim(is_string($in['nickname']??null)?$in['nickname']:'');
 if (!preg_match('/^[\p{L}\p{N} _.-]{2,24}$/uD',$name)) reply(422,['error'=>'Přezdívka: 2–24 znaků, písmena, čísla, mezery, tečka, pomlčka či podtržítko.']);
 $score=$in['score']??null; $round=$in['round']??null; $duration=$in['duration']??null; $distance=$in['distance']??null;
 if (!is_int($score)||!is_int($round)||!is_numeric($duration)||!is_numeric($distance)) reply(422,['error'=>'Neplatný výsledek.']);
 $duration=(float)$duration; $distance=(float)$distance;
 $wall=microtime(true)-$_SESSION['runs'][$token]['started'];
 $timing=$in['roundTiming']??'distance-v1';
 if (!in_array($timing,['distance-v1','bars-16-v1'],true)) reply(422,['error'=>'Neplatné časování hry.']);
 $expectedRound=$timing==='bars-16-v1'?1+(int)floor($duration/(16*4*60/174)):1+(int)floor($distance/3950);
 // Broad plausibility envelope, not a replay verifier. Pause time may exceed active time.
 if (!is_finite($duration)||!is_finite($distance)||$duration<1||$duration>7200||$wall>7200||$duration>$wall+3||$distance<0||$distance>365*$duration+5||$distance<235*$duration-5||$round!==$expectedRound||$score<0||$score>min(100000000,10000*$duration+10000)) reply(422,['error'=>'Výsledek neodpovídá průběhu hry.']);
 $runId=hash('sha256',$token);
 $q=$db->prepare('INSERT INTO phase_scores (run_id,nickname,score,round_no,duration,avatar_json) VALUES (?,?,?,?,?,?)');
 try { $q->execute([$runId,$name,$score,$round,$duration,isset($_SESSION['runs'][$token]['avatar'])?json_encode($_SESSION['runs'][$token]['avatar']):null]); }
 catch (PDOException $e) { if ($e->getCode()==='23000') reply(409,['error'=>'Tento výsledek už byl odeslán.']); throw $e; }
 unset($_SESSION['runs'][$token]);
 $q=$db->prepare('SELECT COUNT(*)+1 FROM phase_scores WHERE score>? OR (score=? AND round_no>?) OR (score=? AND round_no=? AND id<?)');
 $q->execute([$score,$score,$round,$score,$round,(int)$db->lastInsertId()]);
 reply(200,['rank'=>(int)$q->fetchColumn()]);
} catch (Throwable $e) { error_log('Phase Rider leaderboard: '.$e->getMessage()); reply(503,['error'=>'Žebříček je dočasně nedostupný. Zkus to později.']); }
