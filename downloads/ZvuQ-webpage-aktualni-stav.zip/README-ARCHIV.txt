ZvuQ-webpage — archiv větve main
Zdroj: https://github.com/zvuq/ZvuQ-webpage
Commit: 70ab3cfd15160e8d2b2abb410c8b7d6b70e656a4

Všechny soubory odpovídají uvedenému commitu kromě konfigurací
game/api/private/config.php a config.example.php. V těchto dvou
souborech jsou přístupové údaje nahrazeny šablonou pro veřejné stažení.

Při aktualizaci hostingu ponechte svou existující ostrou konfiguraci.
Tento archiv není aktualizovaná verze společného náhledu ZvuQ-preview;
je to samostatný archiv původního repozitáře ZvuQ-webpage.
