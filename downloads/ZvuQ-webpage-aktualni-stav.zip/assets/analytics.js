/* Cloudflare Web Analytics: sem vlož pouze veřejný token z data-cf-beacon.
   Nikdy sem nevkládej API token, heslo ani Global API Key. */
(() => {
  'use strict';
  const SITE_TOKEN = '2da7318c416740a3a8e1eb5a83e5306d';
  if (!SITE_TOKEN.trim() || !/^https?:$/.test(location.protocol)) return;
  if (document.querySelector('script[src*="static.cloudflareinsights.com/beacon.min.js"]')) return;
  const beacon = document.createElement('script');
  beacon.src = 'https://static.cloudflareinsights.com/beacon.min.js';
  beacon.type = 'module';
  beacon.async = true;
  beacon.setAttribute('data-cf-beacon', JSON.stringify({token: SITE_TOKEN.trim()}));
  document.head.appendChild(beacon);
})();
