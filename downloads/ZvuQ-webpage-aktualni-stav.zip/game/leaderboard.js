(() => {
 'use strict';
 const $=id=>document.getElementById(id);
 let generation=0,run=null,result=null;
 async function api(body){
  if(location.protocol==='file:')throw Error('Online žebříček funguje po nahrání na hosting.');
  const response=await fetch('api/index.php',{method:body?'POST':'GET',credentials:'same-origin',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(12000)});
  let data;try{data=await response.json();}catch(_){throw Error('Žebříček není dostupný. Zkontroluj nastavení PHP na hostingu.');}
  if(!response.ok)throw Error(data.error||'Žebříček není dostupný.');return data;
 }
 async function refresh(){
  $('refreshScores').disabled=true;
  try{const data=await api();const fragment=document.createDocumentFragment();data.scores.forEach((row,i)=>{const tr=document.createElement('tr');[i+1,row.nickname,Number(row.score).toLocaleString('cs-CZ'),row.round].forEach(value=>{const td=document.createElement('td');td.textContent=value;tr.append(td);});fragment.append(tr);});$('leaderRows').replaceChildren(fragment);$('leaderStatus').textContent=data.scores.length?'Pořadí: skóre → kolo → dřívější zápis.':'Zatím žádný set. Buď první.';}
  catch(e){$('leaderStatus').textContent=e.message;}
  finally{$('refreshScores').disabled=false;}
 }
 window.phaseLeaderboard={
  begin(){generation++;result=null;$('scoreForm').hidden=true;$('submitStatus').textContent='';$('submitScore').disabled=false;run=api({action:'start'}).then(data=>({token:data.token}),error=>({error:error.message}));},
  async finish(value){const current=generation;const session=await run;if(current!==generation)return;if(!session||session.error){$('submitStatus').textContent=(session&&session.error)||'Set není připojený k žebříčku.';return;}result={...value,token:session.token};$('scoreForm').hidden=false;$('submitStatus').textContent='Set dohrán: '+value.score.toLocaleString('cs-CZ')+' bodů / kolo '+value.round+'.';}
 };
 function init(){
  try{$('nickname').value=localStorage.getItem('phase-nickname')||'';}catch(_){}
  $('refreshScores').addEventListener('click',refresh);
  $('scoreForm').addEventListener('submit',async e=>{e.preventDefault();if(!result)return;const current=generation;const snapshot=result;$('submitScore').disabled=true;try{const nickname=$('nickname').value.trim();const data=await api({action:'submit',...snapshot,nickname});if(current!==generation)return;try{localStorage.setItem('phase-nickname',nickname);}catch(_){}result=null;$('scoreForm').hidden=true;$('submitStatus').textContent='Zapsáno. Tvoje pořadí při zápisu: #'+data.rank;await refresh();}catch(error){if(current===generation){$('submitStatus').textContent=error.message;$('submitScore').disabled=false;}}});
  refresh();
 }
 document.addEventListener('DOMContentLoaded',init);
})();
