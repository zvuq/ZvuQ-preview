<?php
return [
 'host' => 'localhost',
 'database' => 'DOPLNIT_DATABAZI',
 'user' => 'DOPLNIT_UZIVATELE',
 'password' => 'DOPLNIT_HESLO',
 // Nahraď alespoň 32 náhodnými znaky. Používá se pro anonymizaci IP.
 'secret' => 'DOPLNIT_NAHODNY_TAJNY_KLIC',
];
