-- Spustit jednou v existující databázi se žebříčkem.
ALTER TABLE phase_scores ADD COLUMN avatar_json VARCHAR(512) NULL AFTER duration;
