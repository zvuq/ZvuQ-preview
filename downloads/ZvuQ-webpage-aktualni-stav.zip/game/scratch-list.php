<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$names = [];
foreach (glob(__DIR__ . '/assets/*') ?: [] as $path) {
    $name = basename($path);
    if (is_file($path) && preg_match('/^scratch-[a-z0-9_-]+\.mp3$/i', $name)) {
        $names[] = $name;
    }
}
natcasesort($names);
echo json_encode(array_values($names), JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
