<?
phpinfo();
